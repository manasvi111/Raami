<?php
$servername = "localhost";
$username = "n0203814_n0203814"; // Default XAMPP MySQL username
$password = "Manasvi123"; // Leave blank for XAMPP
$dbname = "n0203814_raami_db"; // The database you created earlier

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
